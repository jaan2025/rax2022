class loginform{
  String Coordinator_Name;
  String Coordinator_Code;
  String login;
  String password;

  loginform(
      { required this.Coordinator_Name,
       required this.Coordinator_Code,
      required this.login,
      required this.password});

  factory loginform.fromJson(dynamic json) {
    return loginform(
        password: json["password"],
        Coordinator_Name: json["Coordinator_Name"],
        Coordinator_Code: json["Coordinator_Code"],
        login: json["login"]);
  }

  // Method to make GET parameters.
  Map toJson() => {
    'Coordinator_Name':Coordinator_Name ,
    'Coordinator_Code': Coordinator_Code,
    'login': login,
    'password': password
  };
}