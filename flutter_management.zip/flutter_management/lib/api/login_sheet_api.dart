import 'dart:convert';

import 'package:http/http.dart' as http;

import '../model/login_model.dart';

class LoginSheetApi {
  Future<List<loginform>> getDataFromGs () async {
    final response = await http.get(Uri.parse("https://script.google.com/macros/s/AKfycbzYJ-Np50cCfK-PztVV5fQyneqRh_4qy2kZyxlvPkKHJ1MpbzZCsNOZ1UmBf5eQs7tucA/exec"));
    print(response);
    var result = jsonDecode(response.body);
    print(result);
    return result;
  }

}