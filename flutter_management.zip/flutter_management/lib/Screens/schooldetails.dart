import 'package:flutter/material.dart';
import 'package:flutter_management/Screens/Alldatascreen.dart';
import 'package:toggle_switch/toggle_switch.dart';

class schooldetails extends StatefulWidget {
  const schooldetails({Key? key}) : super(key: key);

  @override
  State<schooldetails> createState() => _schooldetailsState();
}

class _schooldetailsState extends State<schooldetails> {

  String dropdownvalue = "class 1";

  @override
  Widget build(BuildContext context) {
    return Scaffold(
        backgroundColor: Colors.purple[50],
        resizeToAvoidBottomInset : false,
        body: SingleChildScrollView(
            child: Stack(
                children: <Widget>[
                  Padding(
                      padding:  EdgeInsets.only(top: 50),
                      child: Column(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children:  [
                            SizedBox(
                              width: 400,
                              height: 200,
                              child: Card(
                                shape: RoundedRectangleBorder(
                                  borderRadius: BorderRadius.circular(15.0),),
                                elevation: 5,
                                color:Colors.purple[100],
                                child: Column(
                                    mainAxisAlignment: MainAxisAlignment.center,
                                    children:  [
                                      Text('STANDARD ',
                                        style: TextStyle(
                                          fontFamily: 'SFUIDisplay',
                                          fontSize: 20,
                                          fontWeight: FontWeight.bold,
                                          color: Colors.black,
                                        ),
                                      ),
                                      SizedBox(
                                        width: 200,
                                        child: Card(
                                          shape: RoundedRectangleBorder(
                                            borderRadius: BorderRadius.circular(15.0),),
                                          elevation: 5,
                                          color:Colors.white,
                                          child:  Padding(
                                            padding:  EdgeInsets.all(10),
                                            child: DropdownButton(
                                              value: dropdownvalue,
                                              icon:  Icon(Icons.keyboard_arrow_down),
                                              items:  <String>[
                                                "class 1","class 2","class 3","class 4","class 5","class 6","class 7","class 8","class 9","class 10"
                                              ].map((String items) {
                                                return DropdownMenuItem(
                                                  value: items,
                                                  child: Text(items),
                                                );
                                              }).toList(),
                                              onChanged: (String? newValue) {
                                                setState(() {
                                                  dropdownvalue= newValue!;
                                                });
                                              },
                                            ),
                                          ),
                                        ),
                                      )]
                                ),
                              ),
                            ),
                            SizedBox(
                                width: 300,
                                child: Card(
                                    shape: RoundedRectangleBorder(
                                      borderRadius: BorderRadius.circular(15.0),),
                                    elevation: 5,
                                    color:Colors.white,
                                    child: Padding(
                                        padding:  EdgeInsets.all(20),
                                        child: Column(
                                            children: [
                                              Row(
                                                mainAxisAlignment: MainAxisAlignment.center,
                                                children:  [
                                                  Padding(
                                                    padding: EdgeInsets.all(10),
                                                    child: Column(
                                                      children: [
                                                        Row(
                                                          children: [
                                                            Text('YesAll',style: TextStyle(fontWeight: FontWeight.bold),),
                                                            Radio(value: false, groupValue: null, onChanged: null)
                                                          ],
                                                        ),
                                                      ],
                                                    ),
                                                  ),
                                                  Padding(
                                                    padding: EdgeInsets.all(10),
                                                    child: Column(
                                                      children: [
                                                        Row(
                                                          children: [
                                                            Text('NoAll',style: TextStyle(fontWeight: FontWeight.bold),),
                                                            Radio(value: false, groupValue: null, onChanged: null)
                                                          ],
                                                        ),
                                                      ],
                                                    ),
                                                  ),
                                                ],
                                              ),
                                            ]
                                        )))),

                            SizedBox(
                              width: 300,
                              child: Card(
                                shape: RoundedRectangleBorder(
                                  borderRadius: BorderRadius.circular(15.0),),
                                elevation: 5,
                                color:Colors.white,
                                child: Padding(
                                  padding:  EdgeInsets.all(20),
                                  child: Column(
                                    children: [
                                      Padding(
                                        padding: EdgeInsets.all(8.0),
                                        child: Column(
                                          children: [
                                            Text('1.ENGLISH',
                                              style: TextStyle(fontWeight: FontWeight.bold),
                                            ),
                                        Divider(
                                          color: Colors.black,),
                                            Row(
                                              children: [
                                                Text("1.BC",style: TextStyle(fontSize: 15,color: Colors.black),),
                                                Padding(
                                                    padding: const EdgeInsets.only(left: 29),
                                                    child: ToggleSwitch(
                                                      minWidth: 53.3,
                                                      cornerRadius: 20.0,
                                                      activeBgColors: [[Colors.green[800]!], [Colors.red[800]!]],
                                                      activeFgColor: Colors.white,
                                                      inactiveBgColor: Colors.grey,
                                                      inactiveFgColor: Colors.white,
                                                      initialLabelIndex: 1,
                                                      totalSwitches: 2,
                                                      labels: [
                                                          'Yes',
                                                          'N0'],
                                                      radiusStyle: true,
                                                      onToggle: (index) {
                                                        print('switched to: $index');
                                                      },
                                                    ))
                                              ],
                                            ),
                                          ],
                                        ),
                                      ),
                                      Row(
                                          mainAxisAlignment: MainAxisAlignment.start,
                                          children:  [
                                            Padding(
                                                padding: EdgeInsets.all(8.0),
                                                child: Column(
                                                    children: [
                                                      Row(
                                                        children:[
                                                          Text("2.LP",style: TextStyle(fontSize: 15,color: Colors.black),),
                                                          Padding(
                                                              padding: const EdgeInsets.only(left: 29),
                                                              child: ToggleSwitch(
                                                                minWidth: 53.3,
                                                                cornerRadius: 20.0,
                                                                activeBgColors: [[Colors.green[800]!], [Colors.red[800]!]],
                                                                activeFgColor: Colors.white,
                                                                inactiveBgColor: Colors.grey,
                                                                inactiveFgColor: Colors.white,
                                                                initialLabelIndex: 1,
                                                                totalSwitches: 2,
                                                                labels: [
                                                                  'Yes',
                                                                  'No'],
                                                                radiusStyle: true,
                                                                onToggle: (index) {
                                                                  print('switched to: $index');
                                                                },
                                                              ))
                                                        ],
                                                      )
                                                    ]
                                                )
                                            ),
                                          ]),
                                      Row(
                                          mainAxisAlignment: MainAxisAlignment.start,
                                          children:  [
                                            Padding(
                                                padding: EdgeInsets.all(8.0),
                                                child: Column(
                                                    children: [
                                                      Row(
                                                        children:[
                                                          Text("3.RS",style: TextStyle(fontSize: 15,color: Colors.black),),
                                                          Padding(
                                                              padding: const EdgeInsets.only(left: 29),
                                                              child: ToggleSwitch(
                                                                minWidth: 53.3,
                                                                cornerRadius: 20.0,
                                                                activeBgColors: [[Colors.green[800]!], [Colors.red[800]!]],
                                                                activeFgColor: Colors.white,
                                                                inactiveBgColor: Colors.grey,
                                                                inactiveFgColor: Colors.white,
                                                                initialLabelIndex: 1,
                                                                totalSwitches: 2,
                                                                labels: [
                                                                  'Yes',
                                                                  'No'],
                                                                radiusStyle: true,
                                                                onToggle: (index) {
                                                                  print('switched to: $index');
                                                                },
                                                              ))
                                                        ],
                                                      )
                                                    ]
                                                )
                                            ),
                                          ]
                                      ),
                                      Row(
                                          mainAxisAlignment: MainAxisAlignment.start,
                                          children:  [
                                            Padding(
                                                padding: EdgeInsets.all(8.0),
                                                child: Column(
                                                    children: [
                                                      Row(
                                                        children:[
                                                          Text("4.UA",style: TextStyle(fontSize: 15,color: Colors.black),),
                                                          Padding(
                                                              padding: const EdgeInsets.only(left: 29),
                                                              child: ToggleSwitch(
                                                                minWidth: 53.3,
                                                                cornerRadius: 20.0,
                                                                activeBgColors: [[Colors.green[800]!], [Colors.red[800]!]],
                                                                activeFgColor: Colors.white,
                                                                inactiveBgColor: Colors.grey,
                                                                inactiveFgColor: Colors.white,
                                                                initialLabelIndex: 1,
                                                                totalSwitches: 2,
                                                                labels: [
                                                                  'Yes',
                                                                  'No'],
                                                                radiusStyle: true,
                                                                onToggle: (index) {
                                                                  print('switched to: $index');
                                                                },
                                                              ))
                                                        ],
                                                      )
                                                    ]
                                                )
                                            ),
                                          ]
                                      ),
                                      Row(
                                          mainAxisAlignment: MainAxisAlignment.start,
                                          children:  [
                                            Padding(
                                                padding: EdgeInsets.all(8.0),
                                                child: Column(
                                                    children: [
                                                      Row(
                                                        children:[
                                                          Text("5.NB",style: TextStyle(fontSize: 15,color: Colors.black),),
                                                          Padding(
                                                              padding: const EdgeInsets.only(left: 29),
                                                              child: ToggleSwitch(
                                                                minWidth: 53.3,
                                                                cornerRadius: 20.0,
                                                                activeBgColors: [[Colors.green[800]!], [Colors.red[800]!]],
                                                                activeFgColor: Colors.white,
                                                                inactiveBgColor: Colors.grey,
                                                                inactiveFgColor: Colors.white,
                                                                initialLabelIndex: 1,
                                                                totalSwitches: 2,
                                                                labels: [
                                                                  'Yes',
                                                                  'No'],
                                                                radiusStyle: true,
                                                                onToggle: (index) {
                                                                  print('switched to: $index');
                                                                },
                                                              ))
                                                        ],
                                                      )
                                                    ]
                                                )
                                            ),
                                          ]
                                      ),
                                      Row(
                                          mainAxisAlignment: MainAxisAlignment.start,
                                          children:  [
                                            Padding(
                                                padding: EdgeInsets.all(8.0),
                                                child: Column(
                                                    children: [
                                                      Row(
                                                        children:[
                                                          Text("6.WA",style: TextStyle(fontSize: 15,color: Colors.black),),
                                                          Padding(
                                                              padding: const EdgeInsets.only(left: 29),
                                                              child: ToggleSwitch(
                                                                minWidth: 53.3,
                                                                cornerRadius: 20.0,
                                                                activeBgColors: [[Colors.green[800]!], [Colors.red[800]!]],
                                                                activeFgColor: Colors.white,
                                                                inactiveBgColor: Colors.grey,
                                                                inactiveFgColor: Colors.white,
                                                                initialLabelIndex: 1,
                                                                totalSwitches: 2,
                                                                labels: [
                                                                  'Yes',
                                                                  'No'],
                                                                radiusStyle: true,
                                                                onToggle: (index) {
                                                                  print('switched to: $index');
                                                                },
                                                              ))
                                                        ],
                                                      )
                                                    ]
                                                )
                                            ),
                                          ]
                                      ),
                                    ],
                                  ),
                                ),
                              ),
                            ),

                            SizedBox(
                              width: 300,
                              child: Card(
                                shape: RoundedRectangleBorder(
                                  borderRadius: BorderRadius.circular(15.0),),
                                elevation: 5,
                                color: Colors.white,
                                child:Padding(
                                  padding: const EdgeInsets.all(20),
                                  child: Column(
                                    children: [
                                      Text('2.MATHS',
                                          style: TextStyle(fontWeight: FontWeight.bold),
                                      ),
                                      Divider(
                                        color: Colors.black,),
                                      Row(
                                          mainAxisAlignment: MainAxisAlignment.start,
                                          children:  [
                                            Padding(
                                                padding: EdgeInsets.all(8.0),
                                                child: Column(
                                                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                                    children: [
                                                      Row(
                                                        children:[
                                                          Text("1.BC",style: TextStyle(fontSize: 15,color: Colors.black),),
                                                          Padding(
                                                              padding: const EdgeInsets.only(left: 29),
                                                              child: ToggleSwitch(
                                                                minWidth: 53.3,
                                                                cornerRadius: 20.0,
                                                                activeBgColors: [[Colors.green[800]!], [Colors.red[800]!]],
                                                                activeFgColor: Colors.white,
                                                                inactiveBgColor: Colors.grey,
                                                                inactiveFgColor: Colors.white,
                                                                initialLabelIndex: 1,
                                                                totalSwitches: 2,
                                                                labels: [
                                                                  'Yes',
                                                                  'No'],
                                                                radiusStyle: true,
                                                                onToggle: (index) {
                                                                  print('switched to: $index');
                                                                },
                                                              ))
                                                        ],
                                                      )
                                                    ]
                                                )
                                            ),
                                          ]
                                      ),
                                      Row(
                                          mainAxisAlignment: MainAxisAlignment.start,
                                          children:  [
                                            Padding(
                                                padding: EdgeInsets.all(8.0),
                                                child: Column(
                                                    children: [
                                                      Row(
                                                        children:[
                                                          Text("2.LP",style: TextStyle(fontSize:15,color: Colors.black),),
                                                          Padding(
                                                              padding: const EdgeInsets.only(left: 29),
                                                              child: ToggleSwitch(
                                                                minWidth: 53.3,
                                                                cornerRadius: 20.0,
                                                                activeBgColors: [[Colors.green[800]!], [Colors.red[800]!]],
                                                                activeFgColor: Colors.white,
                                                                inactiveBgColor: Colors.grey,
                                                                inactiveFgColor: Colors.white,
                                                                initialLabelIndex: 1,
                                                                totalSwitches: 2,
                                                                labels: [
                                                                  'Yes',
                                                                  'No'],
                                                                radiusStyle: true,
                                                                onToggle: (index) {
                                                                  print('switched to: $index');
                                                                },
                                                              ))
                                                        ],
                                                      )
                                                    ]
                                                )
                                            ),
                                          ]
                                      ),
                                      Row(
                                          mainAxisAlignment: MainAxisAlignment.start,
                                          children:  [
                                            Padding(
                                                padding: EdgeInsets.all(8.0),
                                                child: Column(
                                                    children: [
                                                      Row(
                                                        children:[
                                                          Text("3.RS",style: TextStyle(fontSize: 15,color: Colors.black),),
                                                          Padding(
                                                              padding: const EdgeInsets.only(left: 29),
                                                              child: ToggleSwitch(
                                                                minWidth: 53.3,
                                                                cornerRadius: 20.0,
                                                                activeBgColors: [[Colors.green[800]!], [Colors.red[800]!]],
                                                                activeFgColor: Colors.white,
                                                                inactiveBgColor: Colors.grey,
                                                                inactiveFgColor: Colors.white,
                                                                initialLabelIndex: 1,
                                                                totalSwitches: 2,
                                                                labels: [
                                                                  'Yes',
                                                                  'No'],
                                                                radiusStyle: true,
                                                                onToggle: (index) {
                                                                  print('switched to: $index');
                                                                },
                                                              ))
                                                        ],
                                                      )
                                                    ]
                                                )
                                            ),
                                          ]
                                      ),
                                      Row(
                                          mainAxisAlignment: MainAxisAlignment.start,
                                          children:  [
                                            Padding(
                                                padding: EdgeInsets.all(8.0),
                                                child: Column(
                                                    children: [
                                                      Row(
                                                        children:[
                                                          Text("4.UA",style: TextStyle(fontSize: 15,color: Colors.black),),
                                                          Padding(
                                                              padding: const EdgeInsets.only(left: 29),
                                                              child: ToggleSwitch(
                                                                minWidth: 53.3,
                                                                cornerRadius: 20.0,
                                                                activeBgColors: [[Colors.green[800]!], [Colors.red[800]!]],
                                                                activeFgColor: Colors.white,
                                                                inactiveBgColor: Colors.grey,
                                                                inactiveFgColor: Colors.white,
                                                                initialLabelIndex: 1,
                                                                totalSwitches: 2,
                                                                labels: [
                                                                  'Yes',
                                                                  'No'],
                                                                radiusStyle: true,
                                                                onToggle: (index) {
                                                                  print('switched to: $index');
                                                                },
                                                              ))
                                                        ],
                                                      )
                                                    ]
                                                )
                                            ),
                                          ]
                                      ),
                                      Row(
                                          mainAxisAlignment: MainAxisAlignment.start,
                                          children:  [
                                            Padding(
                                                padding: EdgeInsets.all(8.0),
                                                child: Column(
                                                    children: [
                                                      Row(
                                                        children:[
                                                          Text("5.NB",style: TextStyle(fontSize: 15,color: Colors.black),),
                                                          Padding(
                                                              padding: const EdgeInsets.only(left: 29),
                                                              child: ToggleSwitch(
                                                                minWidth: 53.3,
                                                                cornerRadius: 20.0,
                                                                activeBgColors: [[Colors.green[800]!], [Colors.red[800]!]],
                                                                activeFgColor: Colors.white,
                                                                inactiveBgColor: Colors.grey,
                                                                inactiveFgColor: Colors.white,
                                                                initialLabelIndex: 1,
                                                                totalSwitches: 2,
                                                                labels: [
                                                                  'Yes',
                                                                  'No'],
                                                                radiusStyle: true,
                                                                onToggle: (index) {
                                                                  print('switched to: $index');
                                                                },
                                                              ))
                                                        ],
                                                      )
                                                    ]
                                                )
                                            ),
                                          ]
                                      ),
                                      Row(
                                          mainAxisAlignment: MainAxisAlignment.start,
                                          children:  [
                                            Padding(
                                                padding: EdgeInsets.all(8.0),
                                                child: Column(
                                                    children: [
                                                      Row(
                                                        children:[
                                                          Text("6.WA",style: TextStyle(fontSize: 15,color: Colors.black),),
                                                          Padding(
                                                              padding: const EdgeInsets.only(left: 29),
                                                              child: ToggleSwitch(
                                                                minWidth: 53.3,
                                                                cornerRadius: 20.0,
                                                                activeBgColors: [[Colors.green[800]!], [Colors.red[800]!]],
                                                                activeFgColor: Colors.white,
                                                                inactiveBgColor: Colors.grey,
                                                                inactiveFgColor: Colors.white,
                                                                initialLabelIndex: 1,
                                                                totalSwitches: 2,
                                                                labels: [
                                                                  'Yes',
                                                                  'No'],
                                                                radiusStyle: true,
                                                                onToggle: (index) {
                                                                  print('switched to: $index');
                                                                },
                                                              ))
                                                        ],
                                                      )
                                                    ]
                                                )
                                            ),
                                          ]
                                      ),
                                    ],
                                  ),
                                ),
                              ),
                            ),

                            SizedBox(
                              width: 300,
                              child: Card(
                                shape: RoundedRectangleBorder(
                                  borderRadius: BorderRadius.circular(15.0),),
                                elevation: 5,
                                color:Colors.white,
                                child: Padding(
                                  padding:  EdgeInsets.all(20),
                                  child: Expanded(
                                    child: Column(
                                      children: [
                                        Padding(
                                          padding: EdgeInsets.all(8.0),
                                          child: Column(
                                            children: [
                                              Text('3.SOCIAL STUDIES',
                                                style: TextStyle(fontWeight: FontWeight.bold),
                                              ),
                                              Divider(
                                                color: Colors.black,),
                                              Row(
                                                children: [
                                                  Text("1.BC",style: TextStyle(fontSize: 15,color: Colors.black),),
                                                  Padding(
                                                      padding: const EdgeInsets.only(left: 29),
                                                      child: ToggleSwitch(
                                                        minWidth: 53.3,
                                                        cornerRadius: 20.0,
                                                        activeBgColors: [[Colors.green[800]!], [Colors.red[800]!]],
                                                        activeFgColor: Colors.white,
                                                        inactiveBgColor: Colors.grey,
                                                        inactiveFgColor: Colors.white,
                                                        initialLabelIndex: 1,
                                                        totalSwitches: 2,
                                                        labels: [
                                                          'Yes',
                                                          'No'],
                                                        radiusStyle: true,
                                                        onToggle: (index) {
                                                          print('switched to: $index');
                                                        },
                                                      ))
                                                ],
                                              ),
                                            ],
                                          ),
                                        ),
                                        Row(
                                            mainAxisAlignment: MainAxisAlignment.start,
                                            children:  [
                                              Padding(
                                                  padding: EdgeInsets.all(8.0),
                                                  child: Column(
                                                      children: [
                                                        Row(
                                                          children:[
                                                            Text("2.LP",style: TextStyle(fontSize: 15,color: Colors.black),),
                                                            Padding(
                                                                padding: const EdgeInsets.only(left: 29),
                                                                child: ToggleSwitch(
                                                                  minWidth: 53.3,
                                                                  cornerRadius: 20.0,
                                                                  activeBgColors: [[Colors.green[800]!], [Colors.red[800]!]],
                                                                  activeFgColor: Colors.white,
                                                                  inactiveBgColor: Colors.grey,
                                                                  inactiveFgColor: Colors.white,
                                                                  initialLabelIndex: 1,
                                                                  totalSwitches: 2,
                                                                  labels: [
                                                                    'Yes',
                                                                    'No'],
                                                                  radiusStyle: true,
                                                                  onToggle: (index) {
                                                                    print('switched to: $index');
                                                                  },
                                                                ))
                                                          ],
                                                        )
                                                      ]
                                                  )
                                              ),
                                            ]),
                                        Row(
                                            mainAxisAlignment: MainAxisAlignment.start,
                                            children:  [
                                              Padding(
                                                  padding: EdgeInsets.all(8.0),
                                                  child: Column(
                                                      children: [
                                                        Row(
                                                          children:[
                                                            Text("3.RS",style: TextStyle(fontSize: 15,color: Colors.black),),
                                                            Padding(
                                                                padding: const EdgeInsets.only(left: 29),
                                                                child: ToggleSwitch(
                                                                  minWidth: 53.3,
                                                                  cornerRadius: 20.0,
                                                                  activeBgColors: [[Colors.green[800]!], [Colors.red[800]!]],
                                                                  activeFgColor: Colors.white,
                                                                  inactiveBgColor: Colors.grey,
                                                                  inactiveFgColor: Colors.white,
                                                                  initialLabelIndex: 1,
                                                                  totalSwitches: 2,
                                                                  labels: [
                                                                    'Yes',
                                                                    'No'],
                                                                  radiusStyle: true,
                                                                  onToggle: (index) {
                                                                    print('switched to: $index');
                                                                  },
                                                                ))
                                                          ],
                                                        )
                                                      ]
                                                  )
                                              ),
                                            ]
                                        ),
                                        Row(
                                            mainAxisAlignment: MainAxisAlignment.start,
                                            children:  [
                                              Padding(
                                                  padding: EdgeInsets.all(8.0),
                                                  child: Column(
                                                      children: [
                                                        Row(
                                                          children:[
                                                            Text("4.UA",style: TextStyle(fontSize: 15,color: Colors.black),),
                                                            Padding(
                                                                padding: const EdgeInsets.only(left: 29),
                                                                child: ToggleSwitch(
                                                                  minWidth: 53.3,
                                                                  cornerRadius: 20.0,
                                                                  activeBgColors: [[Colors.green[800]!], [Colors.red[800]!]],
                                                                  activeFgColor: Colors.white,
                                                                  inactiveBgColor: Colors.grey,
                                                                  inactiveFgColor: Colors.white,
                                                                  initialLabelIndex: 1,
                                                                  totalSwitches: 2,
                                                                  labels: [
                                                                    'Yes',
                                                                    'No'],
                                                                  radiusStyle: true,
                                                                  onToggle: (index) {
                                                                    print('switched to: $index');
                                                                  },
                                                                ))
                                                          ],
                                                        )
                                                      ]
                                                  )
                                              ),
                                            ]
                                        ),
                                        Row(
                                            mainAxisAlignment: MainAxisAlignment.start,
                                            children:  [
                                              Padding(
                                                  padding: EdgeInsets.all(8.0),
                                                  child: Column(
                                                      children: [
                                                        Row(
                                                          children:[
                                                            Text("5.NB",style: TextStyle(fontSize: 15,color: Colors.black),),
                                                            Padding(
                                                                padding: const EdgeInsets.only(left: 29),
                                                                child: ToggleSwitch(
                                                                  minWidth: 53.3,
                                                                  cornerRadius: 20.0,
                                                                  activeBgColors: [[Colors.green[800]!], [Colors.red[800]!]],
                                                                  activeFgColor: Colors.white,
                                                                  inactiveBgColor: Colors.grey,
                                                                  inactiveFgColor: Colors.white,
                                                                  initialLabelIndex: 1,
                                                                  totalSwitches: 2,
                                                                  labels: [
                                                                    'Yes',
                                                                    'No'],
                                                                  radiusStyle: true,
                                                                  onToggle: (index) {
                                                                    print('switched to: $index');
                                                                  },
                                                                ))
                                                          ],
                                                        )
                                                      ]
                                                  )
                                              ),
                                            ]
                                        ),
                                        Row(
                                            mainAxisAlignment: MainAxisAlignment.start,
                                            children:  [
                                              Padding(
                                                  padding: EdgeInsets.all(8.0),
                                                  child: Column(
                                                      children: [
                                                        Row(
                                                          children:[
                                                            Text("6.WA",style: TextStyle(fontSize: 15,color: Colors.black),),
                                                            Padding(
                                                                padding: const EdgeInsets.only(left: 29),
                                                                child: ToggleSwitch(
                                                                  minWidth: 53.3,
                                                                  cornerRadius: 20.0,
                                                                  activeBgColors: [[Colors.green[800]!], [Colors.red[800]!]],
                                                                  activeFgColor: Colors.white,
                                                                  inactiveBgColor: Colors.grey,
                                                                  inactiveFgColor: Colors.white,
                                                                  initialLabelIndex: 1,
                                                                  totalSwitches: 2,
                                                                  labels: [
                                                                    'Yes',
                                                                    'No'],
                                                                  radiusStyle: true,
                                                                  onToggle: (index) {
                                                                    print('switched to: $index');
                                                                  },
                                                                ))
                                                          ],
                                                        )
                                                      ]
                                                  )
                                              ),
                                            ]
                                        ),
                                      ],
                                    ),
                                  ),
                                ),
                              ),
                            ),

                            SizedBox(
                              width: 300,
                              child: Card(
                                shape: RoundedRectangleBorder(
                                  borderRadius: BorderRadius.circular(15.0),),
                                elevation: 5,
                                color:Colors.white,
                                child: Padding(
                                  padding:  EdgeInsets.all(20),
                                  child: Expanded(
                                    child: Column(
                                      children: [
                                        Padding(
                                          padding: EdgeInsets.all(8.0),
                                          child: Column(
                                            children: [
                                              Text('4.EVS',
                                                style: TextStyle(fontWeight: FontWeight.bold),
                                              ),
                                              Divider(
                                                color: Colors.black,),
                                              Row(
                                                children: [
                                                  Text("1.BC",style: TextStyle(fontSize: 15,color: Colors.black),),
                                                  Padding(
                                                      padding: const EdgeInsets.only(left: 29),
                                                      child: ToggleSwitch(
                                                        minWidth: 53.3,
                                                        cornerRadius: 20.0,
                                                        activeBgColors: [[Colors.green[800]!], [Colors.red[800]!]],
                                                        activeFgColor: Colors.white,
                                                        inactiveBgColor: Colors.grey,
                                                        inactiveFgColor: Colors.white,
                                                        initialLabelIndex: 1,
                                                        totalSwitches: 2,
                                                        labels: [
                                                          'Yes',
                                                          'No'],
                                                        radiusStyle: true,
                                                        onToggle: (index) {
                                                          print('switched to: $index');
                                                        },
                                                      ))
                                                ],
                                              ),
                                            ],
                                          ),
                                        ),
                                        Row(
                                            mainAxisAlignment: MainAxisAlignment.start,
                                            children:  [
                                              Padding(
                                                  padding: EdgeInsets.all(8.0),
                                                  child: Column(
                                                      children: [
                                                        Row(
                                                          children:[
                                                            Text("2.LP",style: TextStyle(fontSize: 15,color: Colors.black),),
                                                            Padding(
                                                                padding: const EdgeInsets.only(left: 29),
                                                                child: ToggleSwitch(
                                                                  minWidth: 53.3,
                                                                  cornerRadius: 20.0,
                                                                  activeBgColors: [[Colors.green[800]!], [Colors.red[800]!]],
                                                                  activeFgColor: Colors.white,
                                                                  inactiveBgColor: Colors.grey,
                                                                  inactiveFgColor: Colors.white,
                                                                  initialLabelIndex: 1,
                                                                  totalSwitches: 2,
                                                                  labels: [
                                                                    'Yes',
                                                                    'No'],
                                                                  radiusStyle: true,
                                                                  onToggle: (index) {
                                                                    print('switched to: $index');
                                                                  },
                                                                ))
                                                          ],
                                                        )
                                                      ]
                                                  )
                                              ),
                                            ]),
                                        Row(
                                            mainAxisAlignment: MainAxisAlignment.start,
                                            children:  [
                                              Padding(
                                                  padding: EdgeInsets.all(8.0),
                                                  child: Column(
                                                      children: [
                                                        Row(
                                                          children:[
                                                            Text("3.RS",style: TextStyle(fontSize: 15,color: Colors.black),),
                                                            Padding(
                                                                padding: const EdgeInsets.only(left: 29),
                                                                child: ToggleSwitch(
                                                                  minWidth: 53.3,
                                                                  cornerRadius: 20.0,
                                                                  activeBgColors: [[Colors.green[800]!], [Colors.red[800]!]],
                                                                  activeFgColor: Colors.white,
                                                                  inactiveBgColor: Colors.grey,
                                                                  inactiveFgColor: Colors.white,
                                                                  initialLabelIndex: 1,
                                                                  totalSwitches: 2,
                                                                  labels: [
                                                                    'Yes',
                                                                    'No'],
                                                                  radiusStyle: true,
                                                                  onToggle: (index) {
                                                                    print('switched to: $index');
                                                                  },
                                                                ))
                                                          ],
                                                        )
                                                      ]
                                                  )
                                              ),
                                            ]
                                        ),
                                        Row(
                                            mainAxisAlignment: MainAxisAlignment.start,
                                            children:  [
                                              Padding(
                                                  padding: EdgeInsets.all(8.0),
                                                  child: Column(
                                                      children: [
                                                        Row(
                                                          children:[
                                                            Text("4.UA",style: TextStyle(fontSize: 15,color: Colors.black),),
                                                            Padding(
                                                                padding: const EdgeInsets.only(left: 29),
                                                                child: ToggleSwitch(
                                                                  minWidth: 53.3,
                                                                  cornerRadius: 20.0,
                                                                  activeBgColors: [[Colors.green[800]!], [Colors.red[800]!]],
                                                                  activeFgColor: Colors.white,
                                                                  inactiveBgColor: Colors.grey,
                                                                  inactiveFgColor: Colors.white,
                                                                  initialLabelIndex: 1,
                                                                  totalSwitches: 2,
                                                                  labels: [
                                                                    'Yes',
                                                                    'No'],
                                                                  radiusStyle: true,
                                                                  onToggle: (index) {
                                                                    print('switched to: $index');
                                                                  },
                                                                ))
                                                          ],
                                                        )
                                                      ]
                                                  )
                                              ),
                                            ]
                                        ),
                                        Row(
                                            mainAxisAlignment: MainAxisAlignment.start,
                                            children:  [
                                              Padding(
                                                  padding: EdgeInsets.all(8.0),
                                                  child: Column(
                                                      children: [
                                                        Row(
                                                          children:[
                                                            Text("5.NB",style: TextStyle(fontSize: 15,color: Colors.black),),
                                                            Padding(
                                                                padding: const EdgeInsets.only(left: 29),
                                                                child: ToggleSwitch(
                                                                  minWidth: 53.3,
                                                                  cornerRadius: 20.0,
                                                                  activeBgColors: [[Colors.green[800]!], [Colors.red[800]!]],
                                                                  activeFgColor: Colors.white,
                                                                  inactiveBgColor: Colors.grey,
                                                                  inactiveFgColor: Colors.white,
                                                                  initialLabelIndex: 1,
                                                                  totalSwitches: 2,
                                                                  labels: [
                                                                    'Yes',
                                                                    'No'],
                                                                  radiusStyle: true,
                                                                  onToggle: (index) {
                                                                    print('switched to: $index');
                                                                  },
                                                                ))
                                                          ],
                                                        )
                                                      ]
                                                  )
                                              ),
                                            ]
                                        ),
                                        Row(
                                            mainAxisAlignment: MainAxisAlignment.start,
                                            children:  [
                                              Padding(
                                                  padding: EdgeInsets.all(8.0),
                                                  child: Column(
                                                      children: [
                                                        Row(
                                                          children:[
                                                            Text("6.WA",style: TextStyle(fontSize: 15,color: Colors.black),),
                                                            Padding(
                                                                padding: const EdgeInsets.only(left: 29),
                                                                child: ToggleSwitch(
                                                                  minWidth: 53.3,
                                                                  cornerRadius: 20.0,
                                                                  activeBgColors: [[Colors.green[800]!], [Colors.red[800]!]],
                                                                  activeFgColor: Colors.white,
                                                                  inactiveBgColor: Colors.grey,
                                                                  inactiveFgColor: Colors.white,
                                                                  initialLabelIndex: 1,
                                                                  totalSwitches: 2,
                                                                  labels: [
                                                                    'Yes',
                                                                    'No'],
                                                                  radiusStyle: true,
                                                                  onToggle: (index) {
                                                                    print('switched to: $index');
                                                                  },
                                                                ))
                                                          ],
                                                        )
                                                      ]
                                                  )
                                              ),
                                            ]
                                        ),
                                      ],
                                    ),
                                  ),
                                ),
                              ),
                            ),

                            SizedBox(
                              width: 300,
                              child: Card(
                                shape: RoundedRectangleBorder(
                                  borderRadius: BorderRadius.circular(15.0),),
                                elevation: 5,
                                color:Colors.white,
                                child: Padding(
                                  padding:  EdgeInsets.all(20),
                                  child: Expanded(
                                    child: Column(
                                      children: [
                                        Padding(
                                          padding: EdgeInsets.all(8.0),
                                          child: Column(
                                            children: [
                                              Text('5.SCIENCE',
                                                style: TextStyle(fontWeight: FontWeight.bold),
                                              ),
                                              Divider(
                                                color: Colors.black,),
                                              Row(
                                                children: [
                                                  Text("1.BC",style: TextStyle(fontSize: 15,color: Colors.black),),
                                                  Padding(
                                                      padding: const EdgeInsets.only(left: 29),
                                                      child: ToggleSwitch(
                                                        minWidth: 53.3,
                                                        cornerRadius: 20.0,
                                                        activeBgColors: [[Colors.green[800]!], [Colors.red[800]!]],
                                                        activeFgColor: Colors.white,
                                                        inactiveBgColor: Colors.grey,
                                                        inactiveFgColor: Colors.white,
                                                        initialLabelIndex: 1,
                                                        totalSwitches: 2,
                                                        labels: [
                                                          'Yes',
                                                          'No'],
                                                        radiusStyle: true,
                                                        onToggle: (index) {
                                                          print('switched to: $index');
                                                        },
                                                      ))
                                                ],
                                              ),
                                            ],
                                          ),
                                        ),
                                        Row(
                                            mainAxisAlignment: MainAxisAlignment.start,
                                            children:  [
                                              Padding(
                                                  padding: EdgeInsets.all(8.0),
                                                  child: Column(
                                                      children: [
                                                        Row(
                                                          children:[
                                                            Text("2.LP",style: TextStyle(fontSize: 15,color: Colors.black),),
                                                            Padding(
                                                                padding: const EdgeInsets.only(left: 29),
                                                                child: ToggleSwitch(
                                                                  minWidth: 53.3,
                                                                  cornerRadius: 20.0,
                                                                  activeBgColors: [[Colors.green[800]!], [Colors.red[800]!]],
                                                                  activeFgColor: Colors.white,
                                                                  inactiveBgColor: Colors.grey,
                                                                  inactiveFgColor: Colors.white,
                                                                  initialLabelIndex: 1,
                                                                  totalSwitches: 2,
                                                                  labels: [
                                                                    'Yes',
                                                                    'No'],
                                                                  radiusStyle: true,
                                                                  onToggle: (index) {
                                                                    print('switched to: $index');
                                                                  },
                                                                ))
                                                          ],
                                                        )
                                                      ]
                                                  )
                                              ),
                                            ]),
                                        Row(
                                            mainAxisAlignment: MainAxisAlignment.start,
                                            children:  [
                                              Padding(
                                                  padding: EdgeInsets.all(8.0),
                                                  child: Column(
                                                      children: [
                                                        Row(
                                                          children:[
                                                            Text("3.RS",style: TextStyle(fontSize: 15,color: Colors.black),),
                                                            Padding(
                                                                padding: const EdgeInsets.only(left: 29),
                                                                child: ToggleSwitch(
                                                                  minWidth: 53.3,
                                                                  cornerRadius: 20.0,
                                                                  activeBgColors: [[Colors.green[800]!], [Colors.red[800]!]],
                                                                  activeFgColor: Colors.white,
                                                                  inactiveBgColor: Colors.grey,
                                                                  inactiveFgColor: Colors.white,
                                                                  initialLabelIndex: 1,
                                                                  totalSwitches: 2,
                                                                  labels: [
                                                                    'Yes',
                                                                    'No'],
                                                                  radiusStyle: true,
                                                                  onToggle: (index) {
                                                                    print('switched to: $index');
                                                                  },
                                                                ))
                                                          ],
                                                        )
                                                      ]
                                                  )
                                              ),
                                            ]
                                        ),
                                        Row(
                                            mainAxisAlignment: MainAxisAlignment.start,
                                            children:  [
                                              Padding(
                                                  padding: EdgeInsets.all(8.0),
                                                  child: Column(
                                                      children: [
                                                        Row(
                                                          children:[
                                                            Text("4.UA",style: TextStyle(fontSize: 15,color: Colors.black),),
                                                            Padding(
                                                                padding: const EdgeInsets.only(left: 29),
                                                                child: ToggleSwitch(
                                                                  minWidth: 53.3,
                                                                  cornerRadius: 20.0,
                                                                  activeBgColors: [[Colors.green[800]!], [Colors.red[800]!]],
                                                                  activeFgColor: Colors.white,
                                                                  inactiveBgColor: Colors.grey,
                                                                  inactiveFgColor: Colors.white,
                                                                  initialLabelIndex: 1,
                                                                  totalSwitches: 2,
                                                                  labels: [
                                                                    'Yes',
                                                                    'No'],
                                                                  radiusStyle: true,
                                                                  onToggle: (index) {
                                                                    print('switched to: $index');
                                                                  },
                                                                ))
                                                          ],
                                                        )
                                                      ]
                                                  )
                                              ),
                                            ]
                                        ),
                                        Row(
                                            mainAxisAlignment: MainAxisAlignment.start,
                                            children:  [
                                              Padding(
                                                  padding: EdgeInsets.all(8.0),
                                                  child: Column(
                                                      children: [
                                                        Row(
                                                          children:[
                                                            Text("5.NB",style: TextStyle(fontSize: 15,color: Colors.black),),
                                                            Padding(
                                                                padding: const EdgeInsets.only(left: 29),
                                                                child: ToggleSwitch(
                                                                  minWidth: 53.3,
                                                                  cornerRadius: 20.0,
                                                                  activeBgColors: [[Colors.green[800]!], [Colors.red[800]!]],
                                                                  activeFgColor: Colors.white,
                                                                  inactiveBgColor: Colors.grey,
                                                                  inactiveFgColor: Colors.white,
                                                                  initialLabelIndex: 1,
                                                                  totalSwitches: 2,
                                                                  labels: [
                                                                    'Yes',
                                                                    'No'],
                                                                  radiusStyle: true,
                                                                  onToggle: (index) {
                                                                    print('switched to: $index');
                                                                  },
                                                                ))
                                                          ],
                                                        )
                                                      ]
                                                  )
                                              ),
                                            ]
                                        ),
                                        Row(
                                            mainAxisAlignment: MainAxisAlignment.start,
                                            children:  [
                                              Padding(
                                                  padding: EdgeInsets.all(8.0),
                                                  child: Column(
                                                      children: [
                                                        Row(
                                                          children:[
                                                            Text("6.WA",style: TextStyle(fontSize: 15,color: Colors.black),),
                                                            Padding(
                                                                padding: const EdgeInsets.only(left: 29),
                                                                child: ToggleSwitch(
                                                                  minWidth: 53.3,
                                                                  cornerRadius: 20.0,
                                                                  activeBgColors: [[Colors.green[800]!], [Colors.red[800]!]],
                                                                  activeFgColor: Colors.white,
                                                                  inactiveBgColor: Colors.grey,
                                                                  inactiveFgColor: Colors.white,
                                                                  initialLabelIndex: 1,
                                                                  totalSwitches: 2,
                                                                  labels: [
                                                                    'Yes',
                                                                    'No'],
                                                                  radiusStyle: true,
                                                                  onToggle: (index) {
                                                                    print('switched to: $index');
                                                                  },
                                                                ))
                                                          ],
                                                        )
                                                      ]
                                                  )
                                              ),
                                            ]
                                        ),
                                      ],
                                    ),
                                  ),
                                ),
                              ),
                            ),

                            SizedBox(
                              width: 300,
                              child: Card(
                                shape: RoundedRectangleBorder(
                                  borderRadius: BorderRadius.circular(15.0),),
                                elevation: 5,
                                color:Colors.white,
                                child: Padding(
                                  padding:  EdgeInsets.all(20),
                                  child: Expanded(
                                    child: Column(
                                      children: [
                                        Padding(
                                          padding: EdgeInsets.all(8.0),
                                          child: Column(
                                            children: [
                                              Text('6.HINDI',
                                                style: TextStyle(fontWeight: FontWeight.bold),
                                              ),
                                              Divider(
                                                color: Colors.black,),
                                              Row(
                                                children: [
                                                  Text("1.BC",style: TextStyle(fontSize: 15,color: Colors.black),),
                                                  Padding(
                                                      padding: const EdgeInsets.only(left: 29),
                                                      child: ToggleSwitch(
                                                        minWidth: 53.3,
                                                        cornerRadius: 20.0,
                                                        activeBgColors: [[Colors.green[800]!], [Colors.red[800]!]],
                                                        activeFgColor: Colors.white,
                                                        inactiveBgColor: Colors.grey,
                                                        inactiveFgColor: Colors.white,
                                                        initialLabelIndex: 1,
                                                        totalSwitches: 2,
                                                        labels: [
                                                          'Yes',
                                                          'No'],
                                                        radiusStyle: true,
                                                        onToggle: (index) {
                                                          print('switched to: $index');
                                                        },
                                                      ))
                                                ],
                                              ),
                                            ],
                                          ),
                                        ),
                                        Row(
                                            mainAxisAlignment: MainAxisAlignment.start,
                                            children:  [
                                              Padding(
                                                  padding: EdgeInsets.all(8.0),
                                                  child: Column(
                                                      children: [
                                                        Row(
                                                          children:[
                                                            Text("2.LP",style: TextStyle(fontSize: 15,color: Colors.black),),
                                                            Padding(
                                                                padding: const EdgeInsets.only(left: 29),
                                                                child: ToggleSwitch(
                                                                  minWidth: 53.3,
                                                                  cornerRadius: 20.0,
                                                                  activeBgColors: [[Colors.green[800]!], [Colors.red[800]!]],
                                                                  activeFgColor: Colors.white,
                                                                  inactiveBgColor: Colors.grey,
                                                                  inactiveFgColor: Colors.white,
                                                                  initialLabelIndex: 1,
                                                                  totalSwitches: 2,
                                                                  labels: [
                                                                    'Yes',
                                                                    'No'],
                                                                  radiusStyle: true,
                                                                  onToggle: (index) {
                                                                    print('switched to: $index');
                                                                  },
                                                                ))
                                                          ],
                                                        )
                                                      ]
                                                  )
                                              ),
                                            ]),
                                        Row(
                                            mainAxisAlignment: MainAxisAlignment.start,
                                            children:  [
                                              Padding(
                                                  padding: EdgeInsets.all(8.0),
                                                  child: Column(
                                                      children: [
                                                        Row(
                                                          children:[
                                                            Text("3.RS",style: TextStyle(fontSize: 15,color: Colors.black),),
                                                            Padding(
                                                                padding: const EdgeInsets.only(left: 29),
                                                                child: ToggleSwitch(
                                                                  minWidth: 53.3,
                                                                  cornerRadius: 20.0,
                                                                  activeBgColors: [[Colors.green[800]!], [Colors.red[800]!]],
                                                                  activeFgColor: Colors.white,
                                                                  inactiveBgColor: Colors.grey,
                                                                  inactiveFgColor: Colors.white,
                                                                  initialLabelIndex: 1,
                                                                  totalSwitches: 2,
                                                                  labels: [
                                                                    'Yes',
                                                                    'No'],
                                                                  radiusStyle: true,
                                                                  onToggle: (index) {
                                                                    print('switched to: $index');
                                                                  },
                                                                ))
                                                          ],
                                                        )
                                                      ]
                                                  )
                                              ),
                                            ]
                                        ),
                                        Row(
                                            mainAxisAlignment: MainAxisAlignment.start,
                                            children:  [
                                              Padding(
                                                  padding: EdgeInsets.all(8.0),
                                                  child: Column(
                                                      children: [
                                                        Row(
                                                          children:[
                                                            Text("4.UA",style: TextStyle(fontSize: 15,color: Colors.black),),
                                                            Padding(
                                                                padding: const EdgeInsets.only(left: 29),
                                                                child: ToggleSwitch(
                                                                  minWidth: 53.3,
                                                                  cornerRadius: 20.0,
                                                                  activeBgColors: [[Colors.green[800]!], [Colors.red[800]!]],
                                                                  activeFgColor: Colors.white,
                                                                  inactiveBgColor: Colors.grey,
                                                                  inactiveFgColor: Colors.white,
                                                                  initialLabelIndex: 1,
                                                                  totalSwitches: 2,
                                                                  labels: [
                                                                    'Yes',
                                                                    'No'],
                                                                  radiusStyle: true,
                                                                  onToggle: (index) {
                                                                    print('switched to: $index');
                                                                  },
                                                                ))
                                                          ],
                                                        )
                                                      ]
                                                  )
                                              ),
                                            ]
                                        ),
                                        Row(
                                            mainAxisAlignment: MainAxisAlignment.start,
                                            children:  [
                                              Padding(
                                                  padding: EdgeInsets.all(8.0),
                                                  child: Column(
                                                      children: [
                                                        Row(
                                                          children:[
                                                            Text("5.NB",style: TextStyle(fontSize: 15,color: Colors.black),),
                                                            Padding(
                                                                padding: const EdgeInsets.only(left: 29),
                                                                child: ToggleSwitch(
                                                                  minWidth: 53.3,
                                                                  cornerRadius: 20.0,
                                                                  activeBgColors: [[Colors.green[800]!], [Colors.red[800]!]],
                                                                  activeFgColor: Colors.white,
                                                                  inactiveBgColor: Colors.grey,
                                                                  inactiveFgColor: Colors.white,
                                                                  initialLabelIndex: 1,
                                                                  totalSwitches: 2,
                                                                  labels: [
                                                                    'Yes',
                                                                    'No'],
                                                                  radiusStyle: true,
                                                                  onToggle: (index) {
                                                                    print('switched to: $index');
                                                                  },
                                                                ))
                                                          ],
                                                        )
                                                      ]
                                                  )
                                              ),
                                            ]
                                        ),
                                        Row(
                                            mainAxisAlignment: MainAxisAlignment.start,
                                            children:  [
                                              Padding(
                                                  padding: EdgeInsets.all(8.0),
                                                  child: Column(
                                                      children: [
                                                        Row(
                                                          children:[
                                                            Text("6.WA",style: TextStyle(fontSize: 15,color: Colors.black),),
                                                            Padding(
                                                                padding: const EdgeInsets.only(left: 29),
                                                                child: ToggleSwitch(
                                                                  minWidth: 53.3,
                                                                  cornerRadius: 20.0,
                                                                  activeBgColors: [[Colors.green[800]!], [Colors.red[800]!]],
                                                                  activeFgColor: Colors.white,
                                                                  inactiveBgColor: Colors.grey,
                                                                  inactiveFgColor: Colors.white,
                                                                  initialLabelIndex: 1,
                                                                  totalSwitches: 2,
                                                                  labels: [
                                                                    'Yes',
                                                                    'No'],
                                                                  radiusStyle: true,
                                                                  onToggle: (index) {
                                                                    print('switched to: $index');
                                                                  },
                                                                ))
                                                          ],
                                                        )
                                                      ]
                                                  )
                                              ),
                                            ]
                                        ),
                                      ],
                                    ),
                                  ),
                                ),
                              ),
                            ),

                            SizedBox(
                              width: 300,
                              child: Card(
                                shape: RoundedRectangleBorder(
                                  borderRadius: BorderRadius.circular(15.0),),
                                elevation: 5,
                                color:Colors.white,
                                child: Padding(
                                  padding:  EdgeInsets.all(20),
                                  child: Expanded(
                                    child: Column(
                                      children: [
                                        Padding(
                                          padding: EdgeInsets.all(8.0),
                                          child: Column(
                                            children: [
                                              Text('7.URDU',
                                                style: TextStyle(fontWeight: FontWeight.bold),
                                              ),
                                              Divider(
                                                color: Colors.black,),
                                              Row(
                                                children: [
                                                  Text("1.BC",style: TextStyle(fontSize: 15,color: Colors.black),),
                                                  Padding(
                                                      padding: const EdgeInsets.only(left: 29),
                                                      child: ToggleSwitch(
                                                        minWidth: 53.3,
                                                        cornerRadius: 20.0,
                                                        activeBgColors: [[Colors.green[800]!], [Colors.red[800]!]],
                                                        activeFgColor: Colors.white,
                                                        inactiveBgColor: Colors.grey,
                                                        inactiveFgColor: Colors.white,
                                                        initialLabelIndex: 1,
                                                        totalSwitches: 2,
                                                        labels: [
                                                          'Yes',
                                                          'No'],
                                                        radiusStyle: true,
                                                        onToggle: (index) {
                                                          print('switched to: $index');
                                                        },
                                                      ))
                                                ],
                                              ),
                                            ],
                                          ),
                                        ),
                                        Row(
                                            mainAxisAlignment: MainAxisAlignment.start,
                                            children:  [
                                              Padding(
                                                  padding: EdgeInsets.all(8.0),
                                                  child: Column(
                                                      children: [
                                                        Row(
                                                          children:[
                                                            Text("2.LP",style: TextStyle(fontSize: 15,color: Colors.black),),
                                                            Padding(
                                                                padding: const EdgeInsets.only(left: 29),
                                                                child: ToggleSwitch(
                                                                  minWidth: 53.3,
                                                                  cornerRadius: 20.0,
                                                                  activeBgColors: [[Colors.green[800]!], [Colors.red[800]!]],
                                                                  activeFgColor: Colors.white,
                                                                  inactiveBgColor: Colors.grey,
                                                                  inactiveFgColor: Colors.white,
                                                                  initialLabelIndex: 1,
                                                                  totalSwitches: 2,
                                                                  labels: [
                                                                    'Yes',
                                                                    'No'],
                                                                  radiusStyle: true,
                                                                  onToggle: (index) {
                                                                    print('switched to: $index');
                                                                  },
                                                                ))
                                                          ],
                                                        )
                                                      ]
                                                  )
                                              ),
                                            ]),
                                        Row(
                                            mainAxisAlignment: MainAxisAlignment.start,
                                            children:  [
                                              Padding(
                                                  padding: EdgeInsets.all(8.0),
                                                  child: Column(
                                                      children: [
                                                        Row(
                                                          children:[
                                                            Text("3.RS",style: TextStyle(fontSize: 15,color: Colors.black),),
                                                            Padding(
                                                                padding: const EdgeInsets.only(left: 29),
                                                                child: ToggleSwitch(
                                                                  minWidth: 53.3,
                                                                  cornerRadius: 20.0,
                                                                  activeBgColors: [[Colors.green[800]!], [Colors.red[800]!]],
                                                                  activeFgColor: Colors.white,
                                                                  inactiveBgColor: Colors.grey,
                                                                  inactiveFgColor: Colors.white,
                                                                  initialLabelIndex: 1,
                                                                  totalSwitches: 2,
                                                                  labels: [
                                                                    'Yes',
                                                                    'No'],
                                                                  radiusStyle: true,
                                                                  onToggle: (index) {
                                                                    print('switched to: $index');
                                                                  },
                                                                ))
                                                          ],
                                                        )
                                                      ]
                                                  )
                                              ),
                                            ]
                                        ),
                                        Row(
                                            mainAxisAlignment: MainAxisAlignment.start,
                                            children:  [
                                              Padding(
                                                  padding: EdgeInsets.all(8.0),
                                                  child: Column(
                                                      children: [
                                                        Row(
                                                          children:[
                                                            Text("4.UA",style: TextStyle(fontSize: 15,color: Colors.black),),
                                                            Padding(
                                                                padding: const EdgeInsets.only(left: 29),
                                                                child: ToggleSwitch(
                                                                  minWidth: 53.3,
                                                                  cornerRadius: 20.0,
                                                                  activeBgColors: [[Colors.green[800]!], [Colors.red[800]!]],
                                                                  activeFgColor: Colors.white,
                                                                  inactiveBgColor: Colors.grey,
                                                                  inactiveFgColor: Colors.white,
                                                                  initialLabelIndex: 1,
                                                                  totalSwitches: 2,
                                                                  labels: [
                                                                    'Yes',
                                                                    'No'],
                                                                  radiusStyle: true,
                                                                  onToggle: (index) {
                                                                    print('switched to: $index');
                                                                  },
                                                                ))
                                                          ],
                                                        )
                                                      ]
                                                  )
                                              ),
                                            ]
                                        ),
                                        Row(
                                            mainAxisAlignment: MainAxisAlignment.start,
                                            children:  [
                                              Padding(
                                                  padding: EdgeInsets.all(8.0),
                                                  child: Column(
                                                      children: [
                                                        Row(
                                                          children:[
                                                            Text("5.NB",style: TextStyle(fontSize: 15,color: Colors.black),),
                                                            Padding(
                                                                padding: const EdgeInsets.only(left: 29),
                                                                child: ToggleSwitch(
                                                                  minWidth: 53.3,
                                                                  cornerRadius: 20.0,
                                                                  activeBgColors: [[Colors.green[800]!], [Colors.red[800]!]],
                                                                  activeFgColor: Colors.white,
                                                                  inactiveBgColor: Colors.grey,
                                                                  inactiveFgColor: Colors.white,
                                                                  initialLabelIndex: 1,
                                                                  totalSwitches: 2,
                                                                  labels: [
                                                                    'Yes',
                                                                    'No'],
                                                                  radiusStyle: true,
                                                                  onToggle: (index) {
                                                                    print('switched to: $index');
                                                                  },
                                                                ))
                                                          ],
                                                        )
                                                      ]
                                                  )
                                              ),
                                            ]
                                        ),
                                        Row(
                                            mainAxisAlignment: MainAxisAlignment.start,
                                            children:  [
                                              Padding(
                                                  padding: EdgeInsets.all(8.0),
                                                  child: Column(
                                                      children: [
                                                        Row(
                                                          children:[
                                                            Text("6.WA",style: TextStyle(fontSize: 15,color: Colors.black),),
                                                            Padding(
                                                                padding: const EdgeInsets.only(left: 29),
                                                                child: ToggleSwitch(
                                                                  minWidth: 53.3,
                                                                  cornerRadius: 20.0,
                                                                  activeBgColors: [[Colors.green[800]!], [Colors.red[800]!]],
                                                                  activeFgColor: Colors.white,
                                                                  inactiveBgColor: Colors.grey,
                                                                  inactiveFgColor: Colors.white,
                                                                  initialLabelIndex: 1,
                                                                  totalSwitches: 2,
                                                                  labels: [
                                                                    'Yes',
                                                                    'No'],
                                                                  radiusStyle: true,
                                                                  onToggle: (index) {
                                                                    print('switched to: $index');
                                                                  },
                                                                ))
                                                          ],
                                                        )
                                                      ]
                                                  )
                                              ),
                                            ]
                                        ),
                                      ],
                                    ),
                                  ),
                                ),
                              ),
                            ),

                            SizedBox(
                              width: 300,
                              child: Card(
                                shape: RoundedRectangleBorder(
                                  borderRadius: BorderRadius.circular(15.0),),
                                elevation: 5,
                                color:Colors.white,
                                child: Padding(
                                  padding:  EdgeInsets.all(20),
                                  child: Expanded(
                                    child: Column(
                                      children: [
                                        Padding(
                                          padding: EdgeInsets.all(8.0),
                                          child: Column(
                                            children: [
                                              Text('8.TELUGU',
                                                style: TextStyle(fontWeight: FontWeight.bold),
                                              ),
                                              Divider(
                                                color: Colors.black,),
                                              Row(
                                                children: [
                                                  Text("1.BC",style: TextStyle(fontSize: 15,color: Colors.black),),
                                                  Padding(
                                                      padding: const EdgeInsets.only(left: 29),
                                                      child: ToggleSwitch(
                                                        minWidth: 53.3,
                                                        cornerRadius: 20.0,
                                                        activeBgColors: [[Colors.green[800]!], [Colors.red[800]!]],
                                                        activeFgColor: Colors.white,
                                                        inactiveBgColor: Colors.grey,
                                                        inactiveFgColor: Colors.white,
                                                        initialLabelIndex: 1,
                                                        totalSwitches: 2,
                                                        labels: [
                                                          'Yes',
                                                          'No'],
                                                        radiusStyle: true,
                                                        onToggle: (index) {
                                                          print('switched to: $index');
                                                        },
                                                      ))
                                                ],
                                              ),
                                            ],
                                          ),
                                        ),
                                        Row(
                                            mainAxisAlignment: MainAxisAlignment.start,
                                            children:  [
                                              Padding(
                                                  padding: EdgeInsets.all(8.0),
                                                  child: Column(
                                                      children: [
                                                        Row(
                                                          children:[
                                                            Text("2.LP",style: TextStyle(fontSize: 15,color: Colors.black),),
                                                            Padding(
                                                                padding: const EdgeInsets.only(left: 29),
                                                                child: ToggleSwitch(
                                                                  minWidth: 53.3,
                                                                  cornerRadius: 20.0,
                                                                  activeBgColors: [[Colors.green[800]!], [Colors.red[800]!]],
                                                                  activeFgColor: Colors.white,
                                                                  inactiveBgColor: Colors.grey,
                                                                  inactiveFgColor: Colors.white,
                                                                  initialLabelIndex: 1,
                                                                  totalSwitches: 2,
                                                                  labels: [
                                                                    'Yes',
                                                                    'No'],
                                                                  radiusStyle: true,
                                                                  onToggle: (index) {
                                                                    print('switched to: $index');
                                                                  },
                                                                ))
                                                          ],
                                                        )
                                                      ]
                                                  )
                                              ),
                                            ]),
                                        Row(
                                            mainAxisAlignment: MainAxisAlignment.start,
                                            children:  [
                                              Padding(
                                                  padding: EdgeInsets.all(8.0),
                                                  child: Column(
                                                      children: [
                                                        Row(
                                                          children:[
                                                            Text("3.RS",style: TextStyle(fontSize: 15,color: Colors.black),),
                                                            Padding(
                                                                padding: const EdgeInsets.only(left: 29),
                                                                child: ToggleSwitch(
                                                                  minWidth: 53.3,
                                                                  cornerRadius: 20.0,
                                                                  activeBgColors: [[Colors.green[800]!], [Colors.red[800]!]],
                                                                  activeFgColor: Colors.white,
                                                                  inactiveBgColor: Colors.grey,
                                                                  inactiveFgColor: Colors.white,
                                                                  initialLabelIndex: 1,
                                                                  totalSwitches: 2,
                                                                  labels: [
                                                                    'Yes',
                                                                    'No'],
                                                                  radiusStyle: true,
                                                                  onToggle: (index) {
                                                                    print('switched to: $index');
                                                                  },
                                                                ))
                                                          ],
                                                        )
                                                      ]
                                                  )
                                              ),
                                            ]
                                        ),
                                        Row(
                                            mainAxisAlignment: MainAxisAlignment.start,
                                            children:  [
                                              Padding(
                                                  padding: EdgeInsets.all(8.0),
                                                  child: Column(
                                                      children: [
                                                        Row(
                                                          children:[
                                                            Text("4.UA",style: TextStyle(fontSize: 15,color: Colors.black),),
                                                            Padding(
                                                                padding: const EdgeInsets.only(left: 29),
                                                                child: ToggleSwitch(
                                                                  minWidth: 53.3,
                                                                  cornerRadius: 20.0,
                                                                  activeBgColors: [[Colors.green[800]!], [Colors.red[800]!]],
                                                                  activeFgColor: Colors.white,
                                                                  inactiveBgColor: Colors.grey,
                                                                  inactiveFgColor: Colors.white,
                                                                  initialLabelIndex: 1,
                                                                  totalSwitches: 2,
                                                                  labels: [
                                                                    'Yes',
                                                                    'No'],
                                                                  radiusStyle: true,
                                                                  onToggle: (index) {
                                                                    print('switched to: $index');
                                                                  },
                                                                ))
                                                          ],
                                                        )
                                                      ]
                                                  )
                                              ),
                                            ]
                                        ),
                                        Row(
                                            mainAxisAlignment: MainAxisAlignment.start,
                                            children:  [
                                              Padding(
                                                  padding: EdgeInsets.all(8.0),
                                                  child: Column(
                                                      children: [
                                                        Row(
                                                          children:[
                                                            Text("5.NB",style: TextStyle(fontSize: 15,color: Colors.black),),
                                                            Padding(
                                                                padding: const EdgeInsets.only(left: 29),
                                                                child: ToggleSwitch(
                                                                  minWidth: 53.3,
                                                                  cornerRadius: 20.0,
                                                                  activeBgColors: [[Colors.green[800]!], [Colors.red[800]!]],
                                                                  activeFgColor: Colors.white,
                                                                  inactiveBgColor: Colors.grey,
                                                                  inactiveFgColor: Colors.white,
                                                                  initialLabelIndex: 1,
                                                                  totalSwitches: 2,
                                                                  labels: [
                                                                    'Yes',
                                                                    'No'],
                                                                  radiusStyle: true,
                                                                  onToggle: (index) {
                                                                    print('switched to: $index');
                                                                  },
                                                                ))
                                                          ],
                                                        )
                                                      ]
                                                  )
                                              ),
                                            ]
                                        ),
                                        Row(
                                            mainAxisAlignment: MainAxisAlignment.start,
                                            children:  [
                                              Padding(
                                                  padding: EdgeInsets.all(8.0),
                                                  child: Column(
                                                      children: [
                                                        Row(
                                                          children:[
                                                            Text("6.WA",style: TextStyle(fontSize: 15,color: Colors.black),),
                                                            Padding(
                                                                padding: const EdgeInsets.only(left: 29),
                                                                child: ToggleSwitch(
                                                                  minWidth: 53.3,
                                                                  cornerRadius: 20.0,
                                                                  activeBgColors: [[Colors.green[800]!], [Colors.red[800]!]],
                                                                  activeFgColor: Colors.white,
                                                                  inactiveBgColor: Colors.grey,
                                                                  inactiveFgColor: Colors.white,
                                                                  initialLabelIndex: 1,
                                                                  totalSwitches: 2,
                                                                  labels: [
                                                                    'Yes',
                                                                    'No'],
                                                                  radiusStyle: true,
                                                                  onToggle: (index) {
                                                                    print('switched to: $index');
                                                                  },
                                                                ))
                                                          ],
                                                        )
                                                      ]
                                                  )
                                              ),
                                            ]
                                        ),
                                      ],
                                    ),
                                  ),
                                ),
                              ),
                            ),
                            Padding(
                              padding: const EdgeInsets.only(top: 20),
                              child: MaterialButton(
                                onPressed: (){
                                  // LoginSheetApi().getDataFromGs();
                                  Navigator.push(
                                      context,
                                      MaterialPageRoute(builder: (context) =>MyApp()));
                                },//since this is only a UI app
                                child: const Text('Save',
                                  style: TextStyle(
                                    fontSize: 15,
                                    fontFamily: 'SFUIDisplay',
                                    fontWeight: FontWeight.bold,
                                  ),
                                ),
                                color: const Color(0xffff2d55),
                                elevation: 0,
                                minWidth: 200,
                                height: 50,
                                textColor: Colors.white,
                                shape: RoundedRectangleBorder(
                                    borderRadius: BorderRadius.circular(10)
                                ),
                              ),
                            ),
                          ]
                      ))])));
  }
}




