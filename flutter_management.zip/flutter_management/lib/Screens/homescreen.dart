import 'package:flutter/material.dart';
import 'package:flutter_management/Screens/schooldetails.dart';

class Schoolscreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      resizeToAvoidBottomInset : false,
        body: Stack(
          children: <Widget>[
      Container(
      decoration:  BoxDecoration(
      image: DecorationImage(
      image: AssetImage('Assets/image1.png'),
      fit: BoxFit.fitWidth,
      alignment: Alignment.topCenter
      )
      ),
      ),
      Container(
      width: MediaQuery.of(context).size.width,
      margin: const EdgeInsets.only(top: 270),
      decoration: BoxDecoration(
      borderRadius: BorderRadius.circular(20),
      color: Colors.white,
      ),
          child: Padding(
            padding: EdgeInsets.only(top: 100),
            child: Column(
              children:  [
                Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children:  [
                    Text('School Code',
                      style: TextStyle(
                          fontFamily: 'SFUIDisplay',
                          fontSize: 30,
                          fontWeight: FontWeight.bold,
                        color: Colors.red
                      ),
                    ),
                  ],
                ),
                 Padding(
                  padding:  EdgeInsets.only(top:20),
                  child: TextField(
                      obscureText: true,
                      decoration: InputDecoration(
                        border: OutlineInputBorder(),
                        hintText: 'Enter Code',
                        prefixIcon: Icon(Icons.school_sharp),
                      ),
                    ),
                ),

                //
                Padding(
                  padding:  EdgeInsets.only(top: 20),
                  child: MaterialButton(
                    onPressed: (){
                      Navigator.push(
                          context,
                          MaterialPageRoute(builder: (context) => schooldetails()));
                    },//since this is only a UI app
                    child:  Text('GO',
                      style: TextStyle(
                        fontSize: 15,
                        fontFamily: 'SFUIDisplay',
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                    color:  Color(0xffff2d55),
                    elevation: 0,
                    minWidth: 100,
                    height: 50,
                    textColor: Colors.white,
                    shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(10)
                    ),
                  ),
                ),
                ],
            ),
          ),

      ),
          ]
      ),
    );
  }
}